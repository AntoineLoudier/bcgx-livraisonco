# LivraisonCo — Présentation orientée business

Ouvrir **LivraisonCo_business.pdf** pour présenter, ou **LivraisonCo_business.pptx** pour modifier le support. Les neuf slides principales sont éditables ; les huit annexes reprennent les figures et tableaux du PDF d’origine sous forme d’images (titre et pied de page remplacés). L’original `../LivraisonCo_CTM.pdf` est conservé.

## Ce qui change

- L’ouverture présente la valeur opérationnelle et un scénario économique, avant le modèle.
- Trois scénarios explicitent les hypothèses, les économies brutes et le gain net après coûts de solution.
- La partie technique tient en deux slides : principe du modèle et résultats. Les détails passent en annexe.
- Deux maquettes illustrent les usages : site pour l’exploitation, vue mobile pour les livreurs. La direction suit les indicateurs dans le même outil. Ces maquettes ne sont pas une application fonctionnelle.
- La conclusion demande un pilote mesurable : données de tournées, sponsor Ops, comparaison au planning actuel et budget à chiffrer.

## Chiffres et statut des preuves

Les résultats de modèle sont **repris de la page 13 du PDF fourni**, sans nouvel entraînement ni recalcul : −9,3 % de RMSE sur q et −12,4 % sur k face à J−7. Ce sont des réductions d’erreur, pas des taux d’accuracy ni des économies. Les valeurs arrondies du tableau ne permettent pas toujours de retrouver exactement les pourcentages affichés.

La validation Champs-Élysées porte sur 2025 ; le score global mélange des périodes et ne démontre pas la précision de novembre 2026 sur ce capteur. Le dépôt local consulté était sur `main` et ne contenait pas les artefacts de validation associés au support : cette adaptation ne certifie pas à nouveau le protocole. La disponibilité historique des prévisions météo doit être confirmée dans les artefacts du modèle.

Les créneaux de la slide 7 viennent du support initial et restent exploratoires. La fermeture des Champs-Élysées évoquée dans l’original est présentée comme un scénario hérité de 2025, à confirmer pour 2026. Aucun horaire de restriction n’a été vérifié auprès d’une source officielle pendant cette adaptation.

**Toutes les économies et tous les coûts de solution sont illustratifs.** Les taux horaires de 10 € le jour et 14 € la nuit viennent du support initial. Les hypothèses de volumes, part de conduite, réduction, récupération, 6 k€ initiaux et 4 k€/an récurrents sont ajoutées pour rendre le raisonnement économique concret ; ce n’est ni un devis ni un gain observé. Le périmètre concerne les coûts horaires retenus, pas le coût total de livraison.

Calcul central :

```text
Coût horaire annuel de référence = 100 h/jour × 10 €/h × 250 jours = 250 000 €
Part évitable = 40 % de conduite × 20 % de réduction × 70 % récupérables = 5,6 %
Économie brute = 250 000 × 5,6 % = 14 000 €/an
Gain net année 1 = 14 000 − 6 000 − 4 000 = 4 000 €
Gain net récurrent = 14 000 − 4 000 = 10 000 €/an
```

À effectif et heures payées constants, le temps gagné représente d’abord de la capacité. Il ne devient une économie de trésorerie que si l’exploitation peut effectivement réduire les coûts. Aucun lien quantitatif entre gain de RMSE et gain de temps n’a été estimé.

## Utilisation et régénération

Les notes détaillées se trouvent dans les notes du PowerPoint et dans `notes_orateur.md`. Prévoir environ 7–9 minutes pour le corps de présentation ; les annexes servent aux questions.

`hypotheses_business.json` et `scenarios_business.csv` rendent le chiffrage inspectable. Ils sont générés par le script : pour modifier durablement le scénario, éditer le bloc `assumptions` **et les textes correspondants** dans `build_presentation.py`, puis régénérer. Le script n’est pas un simulateur dont tous les textes se recalculent automatiquement.

```bash
uv pip install --python .venv/bin/python python-pptx reportlab pymupdf
.venv/bin/python presentation/build_presentation.py
```

Le générateur utilise les fontes DejaVu Sans du système. Pour une présentation visuellement identique sur un autre ordinateur, privilégier le PDF ou installer cette police. Le PowerPoint n’intègre pas les fontes. Les dépendances de présentation sont séparées de celles du projet ML.

Le PDF a été rendu et inspecté visuellement. Le PowerPoint est généré à partir des mêmes éléments ; ses objets et notes sont vérifiés, mais son rendu dans Microsoft PowerPoint n’a pas été contrôlé ici.
