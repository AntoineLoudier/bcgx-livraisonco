# LivraisonCo — Notes orateur

## 01. Commencer par la valeur

Ouverture : « Notre objectif est de livrer au bon moment pour réduire les heures mobilisées. » Le chiffre de 5,6 % est un scénario de baisse des coûts horaires, pas une baisse du coût total ni un résultat du modèle. Le gain de RMSE est distinct du gain économique. Présenter le chiffrage comme une hypothèse que le pilote doit tester. Équipe : Antoine Loudier, Amin Belfkira, Baptiste Dejardin, Joseph Bouteiller, Louis Jamin. Source des résultats : LivraisonCo_CTM.pdf, page 13. Aucun nouvel entraînement effectué pour cette présentation.

## 02. Un business case calculable

Toutes les hypothèses de volumes, de part de conduite, de réduction, de récupération et de coûts de solution sont illustratives. Le tarif de 10 €/h reprend le cas présenté dans le support initial ; il ne constitue pas un coût employeur complet. Formule : heures × coût horaire × jours × part conduite × réduction conduite × taux de récupération. Le taux de récupération distingue du temps libéré d’heures payées réellement évitées. À salaires et effectifs fixes, ne pas annoncer une économie de trésorerie : mesurer plutôt le débit de livraisons à ressources constantes. En central : 5,6 h/jour, 56 €/jour, 14 000 €/an bruts, 4 000 € nets année 1, puis 10 000 €/an nets récurrents. Le seuil de rentabilité année 1 est 10 000 / 250 000 = 4 % du coût horaire de référence. Aucun coût carburant, pénalité ou gain CO2 n’est comptabilisé sans données. Voir hypotheses_business.json et scenarios_business.csv. Remplacer ces hypothèses par les données Ops avant engagement.

## 03. Relier trafic et décision

Exemple : une tournée de 5 h la nuit coûte 70 € ; il faut plus de 7 h le jour à 10 €/h pour que la nuit soit moins chère. Les taux 10 et 14 €/h proviennent de la slide « Arbitrage jour / nuit » du PDF initial. Le seuil suppose un périmètre de livraisons identique et ignore les différences de coûts autres que les heures. q et k ne sont pas des durées de parcours. La conversion doit être calibrée avec du GPS et les temps d’arrêt avant optimisation économique. Ne pas présenter un faible débit seul comme une preuve de fluidité ; il peut aussi correspondre à une congestion ou une fermeture.

## 04. Garder le modèle compréhensible

Décrire le modèle du support fourni, sans prétendre à une nouvelle vérification du code : ancrage pondéré 60 % J−7, 25 % J−14, 15 % J−21 ; ajustement calendrier ; moyenne des corrections LightGBM et XGBoost. Six couples rue/cible, chacun utilisant les deux familles d’arbres. Les détails et les 48 variables sont conservés en annexe. Le dépôt local consulté est sur main et ne contient pas les artefacts de backtest correspondant au PDF : les scores ne sont pas recalculés. Pour un backtest réaliste, vérifier les millésimes météo disponibles au moment de chaque prévision, pas simplement les observations météo a posteriori.

## 05. Quantifier sans surpromettre

Source : LivraisonCo_CTM.pdf, page 13 (annexe scores), valeurs recopiées. q global : RMSE J−7 112,0 vers 101,6 ; k global : 3,57 vers 3,13. Les variations publiées utilisent probablement les valeurs non arrondies. Les gains sont des réductions d’erreur, pas des taux d’accuracy. k est exprimé en points de pourcentage. Le support décrit une validation sur le passé strict et des cibles réellement observées ; absence d’artefacts locaux permettant une nouvelle certification. Pas d’intervalle de confiance disponible : ne pas affirmer que tous les gains sont statistiquement significatifs. La panne aux Champs-Élysées impose un avertissement de fiabilité et un traitement Ops spécifique. Les scénarios d’événements du 11 novembre et les coefficients de pont doivent être confirmés ; l’historique 2025 ne suffit pas à certifier 2026.

## 06. Raconter la journée utilisateur

Avant de publier le planning, le responsable compare les créneaux et contrôle les alertes de qualité. Il valide avec les contraintes de livraison ; le conducteur reçoit ensuite uniquement une tournée approuvée. Il remonte arrivée, départ et incident. La direction consulte les économies mesurées et la ponctualité. Les deux maquettes sont conceptuelles et éditables dans PowerPoint. Elles ne constituent pas une application livrée ni un moteur de routage. Le créneau affiché est un exemple inspiré du support initial, sans garantie de faisabilité. Une interface web responsive partagée permet de tester les usages avant d’investir dans une application native. L’accès direction est une vue de suivi, pas un troisième produit à développer.

## 07. Transformer une sortie en action

Les créneaux reproduisent les propositions de la page 6 du PDF initial ; ce ne sont pas de nouveaux résultats calculés. Les faire présenter comme des options de planification. Le modèle prévoit q et k et ne résout pas encore une tournée sous contraintes. La fermeture de 8 h à 13 h mentionnée dans le support initial n’a pas été vérifiée pour 2026 ; ne pas l’annoncer comme un arrêté confirmé. De même, l’intensité du pont est une hypothèse. Les Ops doivent vérifier les restrictions officielles, les engagements clients et les capacités. Les courbes détaillées de prévision restent dans le support original ; le corps de cette version privilégie la décision.

## 08. Tester le lien entre modèle et économies

Critère principal : coût opérationnel mesuré / colis effectivement livrés, selon un périmètre de coûts défini avant le test. Garde-fous : taux de livraison à l’heure, échecs de livraison, amplitude des shifts, sécurité et satisfaction utilisateur. Randomiser les tournées ou groupes zone-jour si faisable et éviter qu’un même dispatch mélange les deux politiques. Sinon apparier selon charge, zone et jour et annoncer les limites causales. Comparer l’assistance au planning réellement utilisé, pas seulement au modèle naïf J−7. Dimensionner la durée selon la variance observée et l’effet minimal utile ; ne pas garantir une preuve en deux semaines. Préspécifier une marge acceptable de ponctualité avec les Ops et chiffrer l’incertitude autour des gains. Ne pas annualiser un gain d’une unique journée fériée. Les heures libérées ne sont comptées en euros que si elles sont évitables ou valorisées explicitement en capacité.

## 09. Conclure sur une décision concrète

Le calendrier est indicatif à compter de l’accord, pas un engagement de livraison ou de significativité statistique. Demander un référent exploitation, un accès aux données GPS / commandes / heures et la validation d’un protocole. Les 6 k€ initiaux et 4 k€/an du scénario économique ne sont pas un devis ; les faire chiffrer selon l’architecture et les ressources. Démarrer avec des règles de comparaison de créneaux. Un solveur MILP de shifts et d’affectation peut être ajouté lorsque les temps de parcours, la demande et les contraintes sont mesurés. Repli manuel si données anciennes, événement non confirmé ou sortie incohérente.

## 10. Sources et qualité des données

Page 3 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 11. Détail du modèle

Page 4 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 12. Réel et prédit

Page 9 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 13. Profils horaires

Page 10 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 14. Débit et occupation

Page 11 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 15. Importance des variables

Page 12 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 16. Scores complets

Page 13 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.

## 17. Liste des variables

Page 14 du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.
