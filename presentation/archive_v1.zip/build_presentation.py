"""Génère la présentation business en PDF et PowerPoint (corps éditable).

Usage : .venv/bin/python presentation/build_presentation.py
Dependencies: python-pptx, reportlab, pymupdf.
Les scores sont transcrits du PDF fourni, sans nouvel entraînement.
"""
from pathlib import Path
import csv
import json
import textwrap
import pymupdf
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'LivraisonCo_CTM.pdf'
ASSETS = ROOT / 'assets'
ASSETS.mkdir(exist_ok=True)
W, H = 1280, 720
NAVY, GREEN, MINT = '#102F2C', '#007F60', '#DDF2E8'
INK, MUTED, PAPER, LINE = '#243D3A', '#576C68', '#F5F7F3', '#D8E1DB'
AMBER, PALE = '#9B6218', '#FFF1DA'
WHITE = '#FFFFFF'
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('Body', str(FONT_DIR / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('Bold', str(FONT_DIR / 'DejaVuSans-Bold.ttf')))

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333333), Inches(7.5)
prs.core_properties.title = 'LivraisonCo — Du trafic prévu aux coûts évités'
prs.core_properties.author = 'Les Architectes'
pdf = canvas.Canvas(str(ROOT / 'LivraisonCo_business.pdf'), pagesize=(W, H))
pdf.setTitle(prs.core_properties.title)
pdf.setAuthor('Les Architectes')
notes = []
slide = None
page = 0


def rgb(h):
    return RGBColor.from_string(h.lstrip('#'))


def rect(x, y, w, h, color, radius=0, border=None):
    pdf.setFillColor(color)
    pdf.setStrokeColor(border or color)
    if radius:
        pdf.roundRect(x, H-y-h, w, h, radius, stroke=int(bool(border)), fill=1)
    else:
        pdf.rect(x, H-y-h, w, h, stroke=int(bool(border)), fill=1)
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
        Inches(x/96), Inches(y/96), Inches(w/96), Inches(h/96))
    if radius:
        shape.adjustments[0] = min(radius / min(w, h), 0.5)
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(color)
    if border:
        shape.line.color.rgb = rgb(border)
    else:
        shape.line.fill.background()


def wrap(s, width, size, bold=False):
    font = 'Bold' if bold else 'Body'
    result = []
    for para in s.split('\n'):
        line = ''
        for word in para.split():
            trial = (line + ' ' + word).strip()
            if line and pdfmetrics.stringWidth(trial, font, size) > width:
                result.append(line)
                line = word
            else:
                line = trial
        result.append(line)
    return result


def txt(x, y, s, size=22, color=INK, bold=False, width=1152, leading=None):
    leading = leading or size * 1.32
    lines = wrap(s, width, size, bold)
    height = len(lines) * leading + 8
    if y + height > 717:
        raise ValueError(f'Texte hors page {page}: {s}')
    pdf.setFillColor(color)
    pdf.setFont('Bold' if bold else 'Body', size)
    for i, line in enumerate(lines):
        pdf.drawString(x, H-y-size-i*leading, line)
    box = slide.shapes.add_textbox(Inches(x/96), Inches(y/96), Inches(width/96), Inches(height/96))
    tf = box.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.word_wrap = False
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.font.name = 'DejaVu Sans'
        p.font.size = Pt(size * .75)
        p.font.bold = bold
        p.font.color.rgb = rgb(color)
        p.space_before = p.space_after = Pt(0)
        p.line_spacing = Pt(leading * .75)
    return height


def picture(path, x, y, w, h):
    pdf.drawImage(str(path), x, H-y-h, w, h, preserveAspectRatio=True, anchor='c')
    slide.shapes.add_picture(str(path), Inches(x/96), Inches(y/96), Inches(w/96), Inches(h/96))


def new(section, title, subtitle=None, dark=False):
    global slide, page
    if page:
        pdf.showPage()
    page += 1
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    rect(0, 0, W, H, NAVY if dark else PAPER)
    txt(64, 31, 'LIVRAISONCO  /  LES ARCHITECTES', 13, MINT if dark else GREEN, True)
    txt(880, 31, section.upper(), 13, MINT if dark else MUTED, width=335)
    rect(64, 65, 1152, 2, GREEN)
    if title:
        txt(64, 91, title, 36, WHITE if dark else NAVY, True, width=1152, leading=43)
    if subtitle:
        txt(64, 188, subtitle, 18, MINT if dark else MUTED)
    txt(64, 687, 'BCG X × CentraleSupélec  ·  Point d’étape  ·  6 novembre 2026', 11, MINT if dark else MUTED)
    txt(1160, 683, f'{page:02d}', 15, MINT if dark else MUTED, width=50)


def note(title, content):
    slide.notes_slide.notes_text_frame.text = content
    notes.append(f'## {page:02d}. {title}\n\n{content}\n')


def label(x, y, text, color=GREEN, bg=MINT, w=245):
    rect(x, y, w, 32, bg, 8)
    txt(x+12, y+6, text, 13, color, True, width=w-24)


def card(x, y, w, h, kicker, title, body):
    rect(x, y, w, h, WHITE, 12)
    txt(x+24, y+22, kicker, 13, GREEN, True, width=w-48)
    txt(x+24, y+62, title, 27, NAVY, True, width=w-48)
    txt(x+24, y+150, body, 19, MUTED, width=w-48)


assumptions = {
    'heures_payees_par_jour': 100, 'cout_horaire_jour_eur': 10,
    'jours_par_an': 250, 'part_conduite': 0.40,
    'cout_initial_eur': 6000, 'cout_recurrent_annuel_eur': 4000,
    'scenarios': [
        {'nom': 'Prudent', 'reduction_conduite': .10, 'part_recuperable': .50},
        {'nom': 'Central', 'reduction_conduite': .20, 'part_recuperable': .70},
        {'nom': 'Ambitieux', 'reduction_conduite': .30, 'part_recuperable': .80},
    ],
    'statut': 'Hypothèses illustratives, pas de gain opérationnel mesuré',
}
rows = []
base = assumptions['heures_payees_par_jour'] * assumptions['cout_horaire_jour_eur'] * assumptions['jours_par_an']
for s in assumptions['scenarios']:
    rate = assumptions['part_conduite'] * s['reduction_conduite'] * s['part_recuperable']
    gross = round(base * rate)
    rows.append({**s, 'baisse_couts_horaires': round(rate, 4), 'gain_brut_annuel_eur': gross,
                 'gain_net_an1_eur': gross-10000, 'gain_net_recurrent_eur': gross-4000})
(ROOT / 'hypotheses_business.json').write_text(json.dumps(assumptions, ensure_ascii=False, indent=2)+'\n')
with (ROOT / 'scenarios_business.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

# 1. Impact before the model.
new('01 / Opportunité', '', dark=True)
txt(64, 105, 'Moins de temps dans le trafic.\nPlus de valeur par tournée.', 47, WHITE, True, width=1130, leading=59)
txt(64, 248, 'Anticiper les créneaux difficiles pour mieux planifier les livraisons à Paris.', 22, MINT, width=1070)
rect(64, 326, 430, 237, GREEN, 14)
txt(91, 349, 'SCÉNARIO CENTRAL À VALIDER', 15, WHITE, True, width=380)
txt(91, 385, '−5,6 %', 76, WHITE, True, width=380)
txt(91, 489, 'de coûts horaires évitables\navant coût de la solution', 22, WHITE, width=380)
txt(548, 337, 'Une preuve technique', 25, WHITE, True, width=620)
txt(548, 382, '−9,3 % d’erreur sur le débit, −12,4 % sur l’occupation, face à J−7.', 25, MINT, width=630)
txt(548, 482, 'Une prochaine preuve business', 25, WHITE, True, width=630)
txt(548, 525, 'Mesurer les heures économisées sans dégrader la ponctualité.', 22, MINT, width=630)
txt(64, 602, 'Simulation : 40 % de conduite × 20 % de temps de conduite en moins × 70 % récupérables.\nScores : RMSE du support du 5 novembre ; périmètre et limites en slide 5. Économies non mesurées.', 14, MINT, width=1152)
note('Commencer par la valeur', 'Ouverture : « Notre objectif est de livrer au bon moment pour réduire les heures mobilisées. » '
     'Le chiffre de 5,6 % est un scénario de baisse des coûts horaires, pas une baisse du coût total ni un résultat du modèle. '
     'Le gain de RMSE est distinct du gain économique. Présenter le chiffrage comme une hypothèse que le pilote doit tester. '
     'Équipe : Antoine Loudier, Amin Belfkira, Baptiste Dejardin, Joseph Bouteiller, Louis Jamin. '
     'Source des résultats : LivraisonCo_CTM.pdf, page 13. Aucun nouvel entraînement effectué pour cette présentation.')

# 2. Transparent unit economics.
new('02 / Économie', 'Un scénario simple fait apparaître 14 k€\nd’économies brutes par an',
    'Base illustrative : 100 h payées/jour × 10 €/h × 250 jours = 250 k€/an de coûts horaires.')
cols = [(64, 'Prudent', '10 %', '50 %', '−2,0 %', '5 k€', '−5 k€'),
        (456, 'Central', '20 %', '70 %', '−5,6 %', '14 k€', '+4 k€'),
        (848, 'Ambitieux', '30 %', '80 %', '−9,6 %', '24 k€', '+14 k€')]
for x, name, reduction, recover, rate, gross, net in cols:
    rect(x, 245, 368, 315, MINT if name == 'Central' else WHITE, 12)
    txt(x+24, 266, name.upper(), 15, GREEN, True, width=320)
    txt(x+24, 307, rate, 44, NAVY, True, width=320)
    txt(x+24, 370, f'Conduite : −{reduction}\nGain récupéré : {recover}', 19, MUTED, width=320)
    txt(x+24, 438, f'{gross} bruts / an', 27, NAVY, True, width=320)
    txt(x+24, 493, f'{net} nets en année 1', 21, GREEN if name != 'Prudent' else AMBER, True, width=320)
txt(64, 588, 'Coûts supposés de la solution : 6 k€ au démarrage + 4 k€/an récurrents.\nLe gain devient financier si les heures sont réellement évitées ; sinon, il représente de la capacité libérée.', 17, MUTED, width=1152)
note('Un business case calculable', 'Toutes les hypothèses de volumes, de part de conduite, de réduction, de récupération et de coûts de solution sont illustratives. '
     'Le tarif de 10 €/h reprend le cas présenté dans le support initial ; il ne constitue pas un coût employeur complet. '
     'Formule : heures × coût horaire × jours × part conduite × réduction conduite × taux de récupération. '
     'Le taux de récupération distingue du temps libéré d’heures payées réellement évitées. '
     'À salaires et effectifs fixes, ne pas annoncer une économie de trésorerie : mesurer plutôt le débit de livraisons à ressources constantes. '
     'En central : 5,6 h/jour, 56 €/jour, 14 000 €/an bruts, 4 000 € nets année 1, puis 10 000 €/an nets récurrents. '
     'Le seuil de rentabilité année 1 est 10 000 / 250 000 = 4 % du coût horaire de référence. '
     'Aucun coût carburant, pénalité ou gain CO2 n’est comptabilisé sans données. '
     'Voir hypotheses_business.json et scenarios_business.csv. Remplacer ces hypothèses par les données Ops avant engagement.')

# 3. The decision it supports.
new('03 / Décision', 'Le bon créneau minimise le coût complet\nde la tournée',
    'Une route plus fluide peut coûter plus cher si le créneau impose une prime ou un service dégradé.')
card(64, 245, 355, 294, '01  ANTICIPER', 'Repérer les\nheures à risque', 'Prévoir débit et occupation pour chaque rue, à un horizon de 1 à 5 jours.')
card(462, 245, 355, 294, '02  ARBITRER', 'Comparer des\ncréneaux faisables', 'Ajouter horaires clients, temps d’arrêt, capacité et coûts des équipes.')
card(861, 245, 355, 294, '03  VALIDER', 'Publier un\nplanning accepté', 'L’exploitation valide ; le livreur reçoit sa tournée et signale les écarts.')
rect(64, 567, 1152, 81, MINT, 10)
txt(86, 583, 'Jour / nuit : à 10 €/h contre 14 €/h, la nuit est moins chère seulement si\nla durée de jour dépasse de 40 % la durée de nuit, à travail identique.', 21, NAVY, True, width=1107)
note('Relier trafic et décision', 'Exemple : une tournée de 5 h la nuit coûte 70 € ; il faut plus de 7 h le jour à 10 €/h pour que la nuit soit moins chère. '
     'Les taux 10 et 14 €/h proviennent de la slide « Arbitrage jour / nuit » du PDF initial. '
     'Le seuil suppose un périmètre de livraisons identique et ignore les différences de coûts autres que les heures. '
     'q et k ne sont pas des durées de parcours. La conversion doit être calibrée avec du GPS et les temps d’arrêt avant optimisation économique. '
     'Ne pas présenter un faible débit seul comme une preuve de fluidité ; il peut aussi correspondre à une congestion ou une fermeture.')

# 4. Technical explanation condensed.
new('04 / Prédiction', 'Un modèle lisible combine habitudes\nhebdomadaires et corrections locales',
    '3 rues × 120 heures = 360 lignes prévues, avec deux indicateurs par ligne : débit q et occupation k.')
items = [
    (64, 'LES SIGNAUX', 'Trafic passé\nMétéo prévue\nCalendrier', 'Mesures capteurs, lags hebdomadaires et événements.'),
    (357, 'LE REPÈRE', 'Profil des\nsemaines\nprécédentes', 'Un ancrage simple, ajusté selon le calendrier.'),
    (650, 'LA CORRECTION', 'LightGBM\n+ XGBoost', 'Des arbres corrigent les écarts au profil attendu.'),
    (943, 'LA SORTIE', 'q et k\nheure\npar heure', 'Une lecture par rue pour préparer les créneaux.'),
]
for x, kick, heading, body in items:
    rect(x, 245, 273, 303, WHITE, 12)
    txt(x+21, 269, kick, 14, GREEN, True, width=235)
    txt(x+21, 313, heading, 26, NAVY, True, width=235, leading=33)
    txt(x+21, 442, body, 18, MUTED, width=231)
txt(64, 583, '48 variables · 6 couples rue/cible · Validation sur 4 fenêtres de 5 jours.\nLes données et les prévisions météo doivent être disponibles à la date de décision.', 20, MUTED, width=1152)
note('Garder le modèle compréhensible', 'Décrire le modèle du support fourni, sans prétendre à une nouvelle vérification du code : '
     'ancrage pondéré 60 % J−7, 25 % J−14, 15 % J−21 ; ajustement calendrier ; moyenne des corrections LightGBM et XGBoost. '
     'Six couples rue/cible, chacun utilisant les deux familles d’arbres. Les détails et les 48 variables sont conservés en annexe. '
     'Le dépôt local consulté est sur main et ne contient pas les artefacts de backtest correspondant au PDF : les scores ne sont pas recalculés. '
     'Pour un backtest réaliste, vérifier les millésimes météo disponibles au moment de chaque prévision, pas simplement les observations météo a posteriori.')

# 5. Report precisely, no percentage accuracy invented.
new('05 / Preuve', 'La précision progresse, avec des résultats\nplus solides sur Convention',
    'Réduction de RMSE face à J−7. Résultats reportés du support initial, sur quatre fenêtres de cinq jours.')
rect(64, 245, 345, 326, NAVY, 12)
txt(88, 266, 'GLOBAL · 3 RUES', 15, MINT, True, width=300)
txt(88, 307, '−9,3 %', 48, WHITE, True, width=300)
txt(88, 370, 'Débit q · RMSE 101,6 véh/h', 17, MINT, width=300)
txt(88, 427, '−12,4 %', 48, WHITE, True, width=300)
txt(88, 493, 'Occupation k · RMSE 3,13 pts', 17, MINT, width=300)
rect(438, 245, 778, 326, WHITE, 12)
txt(462, 269, 'RUE', 14, MUTED, True, width=300)
txt(816, 269, 'DÉBIT q', 14, MUTED, True, width=150)
txt(1002, 269, 'OCCUPATION k', 14, MUTED, True, width=200)
for y, street, q, k in [(324, 'Convention', '−21,0 %', '−24,9 %'), (398, 'Saint-Pères', '−3,3 %', '−14,8 %'), (472, 'Champs-Élysées*', '−8,3 %', '−8,1 %')]:
    rect(461, y-13, 729, 1, LINE)
    txt(462, y, street, 22, NAVY, True, width=340)
    txt(816, y, q, 24, GREEN, True, width=160)
    txt(1002, y, k, 24, GREEN, True, width=190)
txt(64, 593, '* Champs-Élysées : validation en 2025 ; capteur muet depuis le 19/11/2025.\nSa performance pour novembre 2026 reste non démontrée. Le score global mélange les périodes.', 18, MUTED, width=1152)
note('Quantifier sans surpromettre', 'Source : LivraisonCo_CTM.pdf, page 13 (annexe scores), valeurs recopiées. '
     'q global : RMSE J−7 112,0 vers 101,6 ; k global : 3,57 vers 3,13. Les variations publiées utilisent probablement les valeurs non arrondies. '
     'Les gains sont des réductions d’erreur, pas des taux d’accuracy. k est exprimé en points de pourcentage. '
     'Le support décrit une validation sur le passé strict et des cibles réellement observées ; absence d’artefacts locaux permettant une nouvelle certification. '
     'Pas d’intervalle de confiance disponible : ne pas affirmer que tous les gains sont statistiquement significatifs. '
     'La panne aux Champs-Élysées impose un avertissement de fiabilité et un traitement Ops spécifique. '
     'Les scénarios d’événements du 11 novembre et les coefficients de pont doivent être confirmés ; l’historique 2025 ne suffit pas à certifier 2026.')

# 6. Users, with editable product mockups (no deployed app promised).
new('06 / Utilisateurs', 'Un écran pour décider, un écran\npour exécuter',
    'Concept d’interface · Contenu illustratif · Le planning reste validé par l’exploitation.')
rect(64, 241, 733, 343, WHITE, 12, LINE)
rect(64, 241, 733, 48, NAVY, 12)
txt(84, 254, 'LIVRAISONCO / EXPLOITATION', 16, WHITE, True, width=600)
label(88, 307, 'PLANIFICATION À 5 JOURS', w=282)
txt(88, 358, 'Rue', 15, MUTED, True, width=190)
txt(293, 358, 'Proposition', 15, MUTED, True, width=220)
txt(540, 358, 'Action', 15, MUTED, True, width=200)
for y, street, slot, status in [(394, 'Convention', 'Matin · à comparer', 'Vérifier les clients'), (439, 'Saint-Pères', 'Matin · à comparer', 'Vérifier la capacité'), (484, 'Champs-Élysées', 'Donnée ancienne', 'Revue manuelle')]:
    rect(88, y-7, 681, 1, LINE)
    txt(88, y, street, 17, INK, width=200)
    txt(293, y, slot, 17, INK, width=240)
    txt(540, y, status, 16, AMBER if y == 484 else GREEN, width=229)
txt(88, 542, 'Direction : coût/colis · ponctualité · heures mobilisées', 17, MUTED, width=680)
rect(859, 241, 307, 343, NAVY, 28)
rect(875, 259, 275, 307, WHITE, 15)
txt(895, 278, 'MA TOURNÉE', 17, GREEN, True, width=235)
txt(895, 318, 'Convention', 25, NAVY, True, width=235)
label(895, 363, 'À CONFIRMER PAR OPS', AMBER, PALE, 235)
txt(895, 410, 'Créneau proposé\n08:00 – 12:00', 21, INK, width=235)
rect(895, 492, 235, 44, GREEN, 8)
txt(908, 503, 'Signaler un retard', 18, WHITE, True, width=211)
txt(64, 613, 'Priorité MVP : un site pour l’exploitation, une vue mobile pour le livreur.\nLa direction suit les gains réalisés ; les contraintes clients priment sur la recommandation trafic.', 18, MUTED, width=1152)
note('Raconter la journée utilisateur', 'Avant de publier le planning, le responsable compare les créneaux et contrôle les alertes de qualité. '
     'Il valide avec les contraintes de livraison ; le conducteur reçoit ensuite uniquement une tournée approuvée. '
     'Il remonte arrivée, départ et incident. La direction consulte les économies mesurées et la ponctualité. '
     'Les deux maquettes sont conceptuelles et éditables dans PowerPoint. Elles ne constituent pas une application livrée ni un moteur de routage. '
     'Le créneau affiché est un exemple inspiré du support initial, sans garantie de faisabilité. '
     'Une interface web responsive partagée permet de tester les usages avant d’investir dans une application native. '
     'L’accès direction est une vue de suivi, pas un troisième produit à développer.')

# 7. Concrete delivery / scope without duplicating busy forecast plots.
new('07 / Cas d’usage', 'Du 7 au 11 novembre : proposer des\ncréneaux, faire confirmer les exceptions',
    'Préconisations exploratoires du support initial ; à croiser avec les livraisons et les restrictions réelles.')
for x, date, title, body in [
    (64, '07–08 NOVEMBRE', 'Week-end\n08 h – 13 h', 'Comparer ce créneau avec les horaires clients et les capacités.'),
    (456, '09–10 NOVEMBRE', 'Lundi / mardi\n08 h – 12 h', 'Vérifier la sensibilité au pont : la baisse de trafic reste une hypothèse.'),
    (848, '11 NOVEMBRE', 'Férié\n14 h – 18 h', 'Confirmer restrictions et réouverture avant de publier une tournée.'),
]:
    card(x, 245, 368, 310, date, title, body)
rect(64, 581, 1152, 71, PALE, 10)
txt(86, 596, 'Champs-Élysées : scénario de fermeture hérité de 2025 + capteur ancien.\nRevue manuelle indispensable ; aucun itinéraire garanti par le modèle.', 19, AMBER, True, width=1105)
note('Transformer une sortie en action', 'Les créneaux reproduisent les propositions de la page 6 du PDF initial ; ce ne sont pas de nouveaux résultats calculés. '
     'Les faire présenter comme des options de planification. Le modèle prévoit q et k et ne résout pas encore une tournée sous contraintes. '
     'La fermeture de 8 h à 13 h mentionnée dans le support initial n’a pas été vérifiée pour 2026 ; ne pas l’annoncer comme un arrêté confirmé. '
     'De même, l’intensité du pont est une hypothèse. Les Ops doivent vérifier les restrictions officielles, les engagements clients et les capacités. '
     'Les courbes détaillées de prévision restent dans le support original ; le corps de cette version privilégie la décision.')

# 8. Pilot and causal measurement.
new('08 / Preuve business', 'Le pilote doit prouver une baisse du\ncoût par livraison, à service constant',
    'Comparer le planning actuel au planning assisté sur des tournées comparables.')
card(64, 245, 368, 290, '01  OBSERVER', 'Mesurer le\ncoût réel', 'GPS, temps d’arrêt, heures payées, colis livrés et retards ; relier chaque trajet à sa tournée.')
card(456, 245, 368, 290, '02  COMPARER', 'Tester une\ndécision différente', 'Affectation aléatoire si possible ; sinon, groupes appariés par zone, jour et charge.')
card(848, 245, 368, 290, '03  DÉCIDER', 'Garder les gains\nqui se confirment', 'Coût par colis livré, ponctualité et faisabilité. Isoler les fériés et incidents.')
rect(64, 563, 1152, 89, MINT, 10)
txt(86, 579, 'Critère proposé : économies nettes positives et ponctualité préservée.\nSeuils, durée et taille du pilote à fixer avec les Ops avant le test.', 22, NAVY, True, width=1107)
note('Tester le lien entre modèle et économies', 'Critère principal : coût opérationnel mesuré / colis effectivement livrés, selon un périmètre de coûts défini avant le test. '
     'Garde-fous : taux de livraison à l’heure, échecs de livraison, amplitude des shifts, sécurité et satisfaction utilisateur. '
     'Randomiser les tournées ou groupes zone-jour si faisable et éviter qu’un même dispatch mélange les deux politiques. '
     'Sinon apparier selon charge, zone et jour et annoncer les limites causales. '
     'Comparer l’assistance au planning réellement utilisé, pas seulement au modèle naïf J−7. '
     'Dimensionner la durée selon la variance observée et l’effet minimal utile ; ne pas garantir une preuve en deux semaines. '
     'Préspécifier une marge acceptable de ponctualité avec les Ops et chiffrer l’incertitude autour des gains. '
     'Ne pas annualiser un gain d’une unique journée fériée. Les heures libérées ne sont comptées en euros que si elles sont évitables ou valorisées explicitement en capacité.')

# 9. Ask / roadmap.
new('09 / Prochaine étape', 'Lancer un pilote ciblé, puis investir\nselon les économies observées',
    'Proposition : commencer sur Convention et Saint-Pères ; traiter les Champs-Élysées en scénario supervisé.')
for x, kick, title, body in [
    (64, 'S1–S2 · INSTRUMENTER', 'Relier trafic,\ntrajets et coûts', 'Référents Ops + Data. Auditer les capteurs et établir la situation de référence.'),
    (456, 'S3–S4 · SIMULER', 'Comparer les\nplannings', 'Calibrer les durées avec le GPS ; tester des règles simples et les contraintes métier.'),
    (848, 'S5–S6 · DÉMARRER', 'Tester avec\nles équipes', 'Mettre la vue web et mobile en pilote ; prolonger la mesure si les données sont insuffisantes.'),
]:
    card(x, 245, 368, 304, kick, title, body)
rect(64, 577, 1152, 75, NAVY, 10)
txt(86, 591, 'Décision demandée : un sponsor Ops, l’accès aux données de tournées\net un budget pilote à chiffrer. L’optimisation avancée vient après la mesure.', 22, WHITE, True, width=1105)
note('Conclure sur une décision concrète', 'Le calendrier est indicatif à compter de l’accord, pas un engagement de livraison ou de significativité statistique. '
     'Demander un référent exploitation, un accès aux données GPS / commandes / heures et la validation d’un protocole. '
     'Les 6 k€ initiaux et 4 k€/an du scénario économique ne sont pas un devis ; les faire chiffrer selon l’architecture et les ressources. '
     'Démarrer avec des règles de comparaison de créneaux. Un solveur MILP de shifts et d’affectation peut être ajouté lorsque les temps de parcours, '
     'la demande et les contraintes sont mesurés. Repli manuel si données anciennes, événement non confirmé ou sortie incohérente.')

# Append the original technical evidence, unchanged, fitted below a clear header.
source = pymupdf.open(SOURCE)
appendices = [(2, 'Sources et qualité des données'), (3, 'Détail du modèle'),
              (8, 'Réel et prédit'), (9, 'Profils horaires'),
              (10, 'Débit et occupation'), (11, 'Importance des variables'),
              (12, 'Scores complets'), (13, 'Liste des variables')]
for idx, title in appendices:
    new('Annexe / Support initial', '')
    txt(64, 84, title, 30, NAVY, True)
    p = source[idx]
    path = ASSETS / f'annexe_source_{idx+1:02d}.png'
    # Retirer uniquement le titre / pied de page d'origine ; conserver le corps.
    clip = pymupdf.Rect(p.rect.width*.035, p.rect.height*.15,
                        p.rect.width*.965, p.rect.height*.935)
    p.get_pixmap(matrix=pymupdf.Matrix(3, 3), clip=clip, alpha=False).save(path)
    w = min(1152, 512 * clip.width / clip.height)
    h = w * clip.height / clip.width
    picture(path, (W-w)/2, 131, w, h)
    txt(64, 655, f'Support du 5 novembre · page source {idx+1} · Contenu technique conservé pour les échanges.', 12, MUTED)
    note(title, f'Page {idx+1} du PDF LivraisonCo_CTM.pdf, reproduite comme image pour préserver figures et chiffres. '
         'Ce contenu technique n’a pas été recalculé. Le corps de présentation distingue les résultats reportés, les hypothèses et les prochaines étapes. '
         'Les textes et chiffres internes à cette image ne sont pas éditables dans PowerPoint.')

pdf.save()
prs.save(ROOT / 'LivraisonCo_business.pptx')
(ROOT / 'notes_orateur.md').write_text('# LivraisonCo — Notes orateur\n\n' + '\n'.join(notes))
print(f'{page} slides générées : 9 principales + {len(appendices)} annexes.')
print(f'PDF et PowerPoint : {ROOT}')
